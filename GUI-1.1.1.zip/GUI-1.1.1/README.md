#framework --or GUI framework @lukau lk 
# this framework is for use in web sites,aplications and outher projects
Cria interfaces com poucos códigos
Faça rápidos trabalho socializando este framework (css,js,...) no seu projecto
"Cria interface sem ter que abrir várias vezes a tag <style>"
Dir
----GUI-1.1.1
     |-css
       |-graphical-ui.css - *estilo css, ui, design,principal, importante
       |-fonts - *não meixer*
     |-js
       |-gui.js - *função, animação, interacção, importante
       |-lib.js - *usa javascript de modo rápido
     |-@mdi - *material design icons
     |-demo.html - * demonstração do GUI
     |-lib.html  - * demonstração da Lib
     |-lisense.txt -* Licença do GUI
     |-package.json -* extrutura de dados
---------------------