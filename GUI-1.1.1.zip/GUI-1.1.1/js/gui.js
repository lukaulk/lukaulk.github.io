elDom={
rg : document.querySelectorAll(".range"),
bar : document.querySelector(".bar"),
driver : document.querySelectorAll(".drive"),
len : document.querySelectorAll(".length"),
click : document.querySelectorAll("#click"),
rup : document.querySelectorAll(".return-up")
}
/*var hdms;var hmd = document.querySelectorAll(".hide-modal");*/
/*for(var n = 0;n <= elDom.driver.length;n++){var leng = document.createElement("span");leng.setAttribute("class","length");elDom.driver[x].appendChild(leng);}*/
for(var i = 0;i < elDom.rg.length;i++){elDom.rg[i].oninput=function(){
const vadge = this.value;for(var x = 0;x <= elDom.driver.length;x++){
this.nextElementSibling.style.left = vadge+"px";
}}}
/*for(ou = 0;ou < elDom.rg.length;ou++){
elDom.rg[ou].onclick=function(){
var leng = document.createElement("span");
leng.setAttribute("class","length");
this.nextElementSibling.appendChild(leng);
}};*/
el={acc : document.getElementsByClassName("accordion"),
pop_acc : document.getElementsByClassName("popup-accordion")}
var x,y;
for (x = 0; x < el.acc.length; x++) {/*loop list of elements length*/
// acc[0].style.setAttribute("border-radius","15px");
var index =0;
el.acc[x].onclick = function(){this.classList.toggle("actived");this.nextElementSibling.classList.toggle("show");}}for(y = 0;y < el.pop_acc.length;y++){el.pop_acc[y].onclick = function(){this.classList.toggle("popin");this.nextElementSibling.classList.toggle("popover");}}
els={amply : document.getElementsByClassName("show-dialog"),meamply : document.getElementsByClassName("me-show-dialog")}
var t;for(t = 0;t < els.amply.length;t++){
els.amply[t].onclick=function(){
this.nextElementSibling.classList.toggle("zoomIn");
index = 1 + index;
this.nextElementSibling.style.zIndex = index;
switch(index){
case 50: index = 0;}

/*document.querySelectorAll("dialog")[t].style.zIndex = index;*/
}}
/*lightboxElements={
main : document.querySelectorAll(".lightbox"),
second : document.querySelectorAll(".image"),
close : document.querySelectorAll(".close-lightbox"),
item : document.querySelectorAll(".item")
};

for(lb = 0;lb < lightboxElements.second.length;lb++){
lightboxElements.close[lb].onclick=function(){
for(var lbs = 0;lbs < lightboxElements.item.length;lbs++){lightboxElements.second[lbs].setAttribute("class","image-hide");}
}
}*/
lightboxElements={
main :  document.querySelectorAll(".image"),
item : document.querySelectorAll(".item"),
chev : document.querySelectorAll(".chevron-btn")
}
var lb;var lb2;
for(lb =0;lb < lightboxElements.main.length;lb++){
lightboxElements.main[lb].onclick=function(){
window.location="#";


};
}
var redirect = 0;
for(lb =0;lb < lightboxElements.item.length;lb++){
lightboxElements.item[lb].onclick=function(){
redirect++;
this.style.zIndex = redirect;
};
}
for(lb = 0;lb < elDom.rup.length;lb++){
elDom.rup[lb].onclick=function(){
window.scrollTo(0,0);
window.style.transition = "1s";
}
}
eltol ={
main : document.querySelectorAll(".show-tooltip"),
}
var tl;
var second = document.querySelectorAll(".tooltip");
for(tl =0;tl < eltol.main.length;tl++){
eltol.main[tl].onclick=function(){

//var a = this.nextElementSibling.classList.toggle("tool");
for(var tlc = 0;tlc < second.length;tlc++){
this.nextElementSibling.classList.toggle("opacity-1");
}
setInterval(function(){
for(var tlc = 0;tlc < second.length;tlc++){
second[tlc].setAttribute("class","tooltip")
}}, 3595)
}}
var main = document.getElementsByClassName("loader");
for(var ll = 0;ll < main.length;ll++){main[ll].innerHTML = "<span class=dot></span> <span class=dot></span> <span class=dot></span> <span class=dot></span>";}
var fctrl  = document.getElementsByClassName("input-lenght-control");
var ct;
for(ct = 0;ct < fctrl.length;ct++){
fctrl[ct].oninput=()=>{
alert(2)
}
}
function preloading(ar){
/*/ loader contents/*/
var ovlc = document.querySelectorAll(".preloader-overlay");
for(var i = 0; i < ovlc.length; i++){ovlc[i].setAttribute("class","easeOut");}
}setInterval(preloading,5500);
