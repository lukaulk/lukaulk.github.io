HTMLElement.prototype.cssStyles=function(clr, bg, brd, ts, pad, mrg, e){
    this.style.background = bg;
    this.style.color = clr;
    this.style.border = brd;
    this.style.fontSize = ts;
    this.style.padding = pad;
    this.style.margin = mrg;
    this.style.boxShadow = e;/* Apenas tem 7 elementos css que pode ser usado */
}
HTMLElement.prototype.when=function event(eName, fn) {  this.addEventListener( eName, fn);}
HTMLElement.prototype.class=function(options, className){
 //   this.classList.add(className);
    if (options == 'removeClass') {
        this.classList.remove(className);
    }else if(options == 'addClass') {
        this.classList.add(className);    
    }else if(options == 'toggleClass' ) {
        this.classList.toggle(className);   
    }

}
HTMLElement.prototype.text=function(ctx) { this.innerHTML = ctx;}
HTMLElement.prototype.show=function() {   this.style.visibility = 'visible';}
HTMLElement.prototype.hide=function() {this.style.visibility = 'hidden';}
HTMLElement.prototype.expandIn=function() { this.classList.add('expand-1');}
HTMLElement.prototype.expandOut=function() { this.classList.add('expand-0');}
